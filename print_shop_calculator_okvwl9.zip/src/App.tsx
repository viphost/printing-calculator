import { Authenticated, Unauthenticated, useMutation, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster, toast } from "sonner";
import { useState } from "react";

export default function App() {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <header className="sticky top-0 z-10 bg-orange-500 text-white p-4 flex justify-between items-center">
        <h2 className="text-xl font-semibold">حاسبة المطبعة</h2>
        <SignOutButton />
      </header>
      <main className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-2xl mx-auto">
          <Content />
        </div>
      </main>
      <Toaster />
    </div>
  );
}

function Content() {
  const [paperSize, setPaperSize] = useState("16/24");
  const [pageCount, setPageCount] = useState("");
  const [quantity, setQuantity] = useState("1");
  const [isUniversity, setIsUniversity] = useState(false);
  const [discount, setDiscount] = useState("");
  
  const calculateCost = useMutation(api.calculator.calculateCost);
  const orders = useQuery(api.calculator.getOrders);
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pageCount || !quantity) {
      toast.error("الرجاء إدخال عدد الصفحات والكمية");
      return;
    }
    
    try {
      const result = await calculateCost({
        paperSize,
        pageCount: parseInt(pageCount),
        quantity: parseInt(quantity),
        isUniversity,
        discount: discount ? parseFloat(discount) : 0,
      });
      
      toast.success(`التكلفة الإجمالية: ${result.totalCost} دج`);
    } catch (error) {
      toast.error("حدث خطأ في الحساب");
    }
  };

  return (
    <div className="flex flex-col gap-8 rtl">
      <div className="text-center">
        <h1 className="text-4xl font-bold mb-4 text-orange-500">حاسبة تكلفة الطباعة</h1>
        <Authenticated>
          <form onSubmit={handleSubmit} className="space-y-4 text-right">
            <div>
              <label className="block mb-2">قياس الكتاب:</label>
              <select 
                value={paperSize}
                onChange={(e) => setPaperSize(e.target.value)}
                className="w-full p-2 border rounded focus:border-orange-500 focus:ring-1 focus:ring-orange-500"
              >
                <option value="16/24">16/24</option>
                <option value="14/22">14/22</option>
              </select>
            </div>
            
            <div>
              <label className="block mb-2">عدد الصفحات:</label>
              <input
                type="number"
                value={pageCount}
                onChange={(e) => setPageCount(e.target.value)}
                className="w-full p-2 border rounded focus:border-orange-500 focus:ring-1 focus:ring-orange-500"
                min="1"
                required
              />
            </div>

            <div>
              <label className="block mb-2">عدد النسخ:</label>
              <input
                type="number"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                className="w-full p-2 border rounded focus:border-orange-500 focus:ring-1 focus:ring-orange-500"
                min="1"
                required
              />
            </div>
            
            <div>
              <label className="block mb-2">نسبة الخصم (%):</label>
              <input
                type="number"
                value={discount}
                onChange={(e) => setDiscount(e.target.value)}
                className="w-full p-2 border rounded focus:border-orange-500 focus:ring-1 focus:ring-orange-500"
                min="0"
                max="100"
                placeholder="اختياري"
              />
            </div>
            
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={isUniversity}
                onChange={(e) => setIsUniversity(e.target.checked)}
                id="isUniversity"
                className="text-orange-500 focus:ring-orange-500"
              />
              <label htmlFor="isUniversity">طباعة جامعية</label>
            </div>
            
            <button
              type="submit"
              className="w-full bg-orange-500 text-white py-2 rounded hover:bg-orange-600 transition-colors"
            >
              حساب التكلفة
            </button>
          </form>
          
          {orders && orders.length > 0 && (
            <div className="mt-8">
              <h2 className="text-2xl font-bold mb-4 text-orange-500">الطلبات السابقة</h2>
              <div className="space-y-2">
                {orders.map((order) => (
                  <div key={order._id} className="border border-orange-200 p-4 rounded bg-orange-50">
                    <p>قياس الكتاب: {order.paperSize}</p>
                    <p>عدد الصفحات: {order.pageCount}</p>
                    <p>عدد النسخ: {order.quantity}</p>
                    <p>التكلفة الإجمالية: {order.totalCost} دج</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </Authenticated>
        
        <Unauthenticated>
          <p className="text-xl text-slate-600 mb-4">قم بتسجيل الدخول للبدء</p>
          <SignInForm />
        </Unauthenticated>
      </div>
    </div>
  );
}
