import { mutation, query } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const calculateCost = mutation({
  args: {
    paperSize: v.string(),
    pageCount: v.number(),
    quantity: v.number(),
    isUniversity: v.boolean(),
    discount: v.number(),
  },
  handler: async (ctx, args) => {
    const { paperSize, pageCount, quantity, isUniversity, discount } = args;
    
    // تكلفة الورق الأساسية
    const regularPaperCost = 4.00;
    const universityPaperCost = 6.00;
    
    // تكلفة الحبر لكل ورقة
    const inkCostPerPage = 3000 / 1500; // 2 دينار لكل ورقة
    
    // حساب التكلفة الإجمالية
    const paperCost = (isUniversity ? universityPaperCost : regularPaperCost) * pageCount;
    const inkCost = inkCostPerPage * pageCount;
    
    let totalCost = (paperCost + inkCost) * quantity;
    
    // تطبيق الخصم إذا كان موجوداً
    if (discount > 0) {
      totalCost = totalCost * (1 - discount / 100);
    }
    
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User not authenticated");
    }
    
    await ctx.db.insert("orders", {
      paperSize,
      pageCount,
      quantity,
      isUniversity,
      discount,
      totalCost: Math.round(totalCost * 100) / 100,
      userId,
    });
    
    return { totalCost: Math.round(totalCost * 100) / 100 };
  },
});

export const getOrders = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];
    
    return await ctx.db
      .query("orders")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .collect();
  },
});
